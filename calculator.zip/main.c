/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b;
    printf("Enter value of a =");
    scanf("%d",&a);
    printf("Enter value of b =");
    scanf("%d",&b);
    
    printf("addition=%d",a+b);
    printf("\nsubstraction=%d",a-b);
    printf("\nmultiplication=%d",a*b);
     printf("\ndivision=%d",a/b);
    printf("\nmodulus=%d",a%b);

return 0;
    
}