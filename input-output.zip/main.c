/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num;
    char ch;
    float f;
 
    printf("Enter the integer: ");
    scanf("%d", &num);
 
    printf("\nEntered integer is: %d", num);
         while((getchar()) != '\n');
 
    printf("\n\nEnter the float: ");
    scanf("%f", &f);
    printf("\nEntered float is: %f", f);
    printf("\n\nEnter the Character: ");
    scanf("%c", &ch);
    printf("\nEntered character is: %c", ch);
    return 0;
}