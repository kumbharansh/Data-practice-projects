
 // C program to print all even numbers from 1 to n

#include <stdio.h>

int main()
{
    int i, n;
  
    printf("Print all even numbers till: ");
    scanf("%d", &n);

    printf("Even numbers from 1 to %d are: \n", n);

    
        if(i%2 == 0)
        {
            printf("%d\n", i);
        }
    }

    return 0;
}