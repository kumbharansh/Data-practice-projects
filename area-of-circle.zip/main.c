/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    float r,area,c;
    float pi=3.14;
     
     printf("Enter value of radius=");
     scanf("%f",&r);
     
     
     area=pi*r*r;
     c=2*pi*r;
     printf("Area of circle =%f\n",area);
    printf("circumference of circle=%f",c); 
     
     
                               
        

}
