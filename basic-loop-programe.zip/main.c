// C program to illustrate need of loops
#include <stdio.h>

int main()
{
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	printf( "Hello World\n");
	
	return 0;
}

